// ==UserScript==
// @name         csdn 代码块自由复制
// @description  真受不了CSDN每一次都能推陈出新，用来恶心用户的新功能。
// @match        *://blog.csdn.net/*/article/details/*
// @match        *://*.blog.csdn.net/article/details/*
// @version 0.0.1.20210914083258
// @namespace https://greasyfork.org/users/815277
// ==/UserScript==

(() => document.querySelectorAll("#content_views pre code").forEach(v => v.style.userSelect = 'text'))()